#! /bin/bash
if [ ! -e /mnt/rootfs ]; then
	mkdir /mnt/rootfs
fi

for x in $( ls /dev/mtd* ); do
  umount $x;
done

flash_unlock /dev/mtd5 0 900
echo "Programing bootstrap..."
flashcp -v /images/bootstrap.bin /dev/mtd0
echo "Programing uboot..."
flashcp -v /images/uboot.bin /dev/mtd1
echo "Programing dtb..."
flashcp -v /images/at91sam9g35ek.dtb /dev/mtd3
echo "Programing kernel..."
flashcp -v /images/zImage /dev/mtd4
echo "Programing rootfs..."
flashcp -v /images/rootfs.squashfs /dev/mtd5
echo "Programing hachfs..."
flashcp -v /images/usr_share_hach.jffs2 /dev/mtd6
echo "Programing jailfs..."
flashcp -v /images/usr_share_jail.jffs2 /dev/mtd7
echo "Programing varfs..."
flashcp -v /images/var.jffs2 /dev/mtd8
flash_lock /dev/mtd5 0 900

mount /dev/mtd8 /mnt/rootfs
chmod 744 /mnt/rootfs/var/empty
umount /dev/mtd8



