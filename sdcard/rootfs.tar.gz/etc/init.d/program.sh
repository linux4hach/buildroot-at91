#! /bin/bash
if [ ! -e /mnt/sd-card ]; then
	mkdir /mnt/sd-card	
fi

mount /dev/mmcblk0p1 /mnt/sd-card
flash_unlock /dev/mtd5 0 900
echo "Programing bootstrap..."
flashcp -v /mnt/sd-card/bootstrap.bin /dev/mtd0
echo "Programing uboot..."
flashcp -v /mnt/sd-card/uboot.bin /dev/mtd1
echo "Programing dtb..."
flashcp -v /mnt/sd-card/at91sam9g35ek.dtb /dev/mtd3
echo "Programing kernel..."
flashcp -v /mnt/sd-card/zImage /dev/mtd4
echo "Programing rootfs..."
flashcp -v /mnt/sd-card/rootfs.squashfs /dev/mtd5
echo "Programing hachfs..."
flashcp -v /mnt/sd-card/usr_share_hach.jffs2 /dev/mtd6
echo "Programing jailfs..."
flashcp -v /mnt/sd-card/usr_share_jail.jffs2 /dev/mtd7
echo "Programing varfs..."
flashcp -v /mnt/sd-card/var.jffs2 /dev/mtd8

flash_lock /dev/mtd5 0 900
umount /mnt/sd-card



